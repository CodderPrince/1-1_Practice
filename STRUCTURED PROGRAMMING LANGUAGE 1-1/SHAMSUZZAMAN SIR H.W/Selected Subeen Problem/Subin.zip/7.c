#include<stdio.h>
#include<string.h>
int main()
{
    int n,i,count;
    char str[100];
    scanf("%d",&n);
    getchar(); // to consume the newline character after n
    for(int j = 0; j < n; j++){
        count = 1;
        fgets(str, 100, stdin);//reads a line of text from the standard input and stores it in the character array str.
        for(i = 0; i < strlen(str); i++){
            if(str[i] == ' '){
                count++;
            }
        }
        printf("%d\n", count);
    }

}
