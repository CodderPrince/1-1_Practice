#include<stdio.h>
#include<string.h>

int main()
{
    int n, i, j;
    int count[26] = {0};
    char str[100];

    printf("Enter the number of test cases: ");
    scanf("%d", &n);

    while(n--){
        getchar(); // consume the newline character
        gets(str);
        fflush(stdin);

        for(i = 0; str[i] != '\0'; i++){
            if(str[i] >= 'a' && str[i] <= 'z'){
                count[str[i] - 'a']++;
            }
        }

        for(j = 0; j < 26; j++){
            if(count[j] != 0){
                printf("'%c' = %d\n", 'a' + j, count[j]);
            }
        }
        memset(count, 0, sizeof(count)); // reset the count array for the next test case
    }
    return 0;
}
